package kr.chatq.server.chatq_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatqServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
