package kr.chatq.server.chatq_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatqServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatqServerApplication.class, args);
	}

}
